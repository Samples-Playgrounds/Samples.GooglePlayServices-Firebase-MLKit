﻿namespace ReproSample.Issue580.GPS.Base;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
