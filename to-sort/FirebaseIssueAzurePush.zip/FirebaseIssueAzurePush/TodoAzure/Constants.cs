﻿namespace TodoAzure
{
    public static class Constants
    {
        // Replace string with your mobile service URL.
        public static string ApplicationURL = @"https://todoazureshane.azurewebsites.net";
    }
}
