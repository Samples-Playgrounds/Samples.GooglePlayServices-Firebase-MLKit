﻿using Android.App;
using Android.Content.PM;
using Android.OS;
using Microsoft.WindowsAzure.MobileServices;
using System;
using System.IO;
using System.Threading.Tasks;

namespace TodoAzure.Droid
{
    [Activity(Label = "TodoAzure.Droid",
        Icon = "@drawable/icon",
        MainLauncher = true,
        ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation,
        Theme = "@android:style/Theme.Holo.Light")]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsApplicationActivity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            global::Xamarin.Forms.Forms.Init(this, bundle);
            Microsoft.WindowsAzure.MobileServices.CurrentPlatform.Init();
            LoadApplication(new App());
        }


        protected override void OnResume()
        {
            base.OnResume();
            Task.Run(async () =>
            {
                try
                {
                    //string token = await LoadTextAsync("filetoken.txt");
                    if (!string.IsNullOrWhiteSpace(Firebase.Iid.FirebaseInstanceId.Instance.Token))
                    {
                        Console.WriteLine(Firebase.Iid.FirebaseInstanceId.Instance.Token);
                    }
                }
                catch(Exception exc)
                {
                    Console.WriteLine(exc.ToString());

                }
            });
            
        }
    }
}
