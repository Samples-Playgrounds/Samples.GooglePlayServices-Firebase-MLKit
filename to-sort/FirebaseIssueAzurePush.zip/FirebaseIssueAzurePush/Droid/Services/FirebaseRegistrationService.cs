﻿using System;
using System.IO;
using System.Threading.Tasks;
using Android.App;
using Android.Util;
using Firebase.Iid;
using Microsoft.WindowsAzure.MobileServices;

namespace TodoAzure.Droid
{
    [Service]
    [IntentFilter(new[] { "com.google.firebase.INSTANCE_ID_EVENT" })]
    public class FirebaseRegistrationService : FirebaseInstanceIdService
    {
        const string TAG = "FirebaseRegistrationService";

        public override void OnTokenRefresh()
        {
            var refreshedToken = FirebaseInstanceId.Instance.Token;
            Log.Debug(TAG, "Refreshed token: " + refreshedToken);
            //SendRegistrationTokenToAzureNotificationHub(refreshedToken);
        }

    }
}
